.. _main_page:

.. include:: ../README.rst
   :start-after: begin_intro
   :end-before: end_intro

Other Content:
--------------

.. toctree::
   :maxdepth: 1

   authorization
   changelog
   reference


.. include:: ../README.rst
   :start-after: begin_installation
   :end-before: end_getting_started
