# This is a dummy authentication file.
# Change the variables to your authentication details and the scripts in this
# folder will work. See scripts/README.rst for more details.

client_id = ""
client_secret = ""
access_token = ""
refresh_token = ""
